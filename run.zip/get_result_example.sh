python show.py 
